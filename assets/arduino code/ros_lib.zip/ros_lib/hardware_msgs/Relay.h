#ifndef _ROS_hardware_msgs_Relay_h
#define _ROS_hardware_msgs_Relay_h

#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "ros/msg.h"

namespace hardware_msgs
{

  class Relay : public ros::Msg
  {
    public:
      bool relay[3];

    Relay():
      relay()
    {
    }

    virtual int serialize(unsigned char *outbuffer) const
    {
      int offset = 0;
      for( uint32_t i = 0; i < 3; i++){
      union {
        bool real;
        uint8_t base;
      } u_relayi;
      u_relayi.real = this->relay[i];
      *(outbuffer + offset + 0) = (u_relayi.base >> (8 * 0)) & 0xFF;
      offset += sizeof(this->relay[i]);
      }
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer)
    {
      int offset = 0;
      for( uint32_t i = 0; i < 3; i++){
      union {
        bool real;
        uint8_t base;
      } u_relayi;
      u_relayi.base = 0;
      u_relayi.base |= ((uint8_t) (*(inbuffer + offset + 0))) << (8 * 0);
      this->relay[i] = u_relayi.real;
      offset += sizeof(this->relay[i]);
      }
     return offset;
    }

    const char * getType(){ return "hardware_msgs/Relay"; };
    const char * getMD5(){ return "752b5a723d30396309a32974961ad972"; };

  };

}
#endif
