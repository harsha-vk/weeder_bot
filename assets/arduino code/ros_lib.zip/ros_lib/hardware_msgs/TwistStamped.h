#ifndef _ROS_hardware_msgs_TwistStamped_h
#define _ROS_hardware_msgs_TwistStamped_h

#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "ros/msg.h"
#include "ros/time.h"

namespace hardware_msgs
{

  class TwistStamped : public ros::Msg
  {
    public:
      typedef ros::Time _stamp_type;
      _stamp_type stamp;
      typedef float _left_wheel_type;
      _left_wheel_type left_wheel;
      typedef float _right_wheel_type;
      _right_wheel_type right_wheel;

    TwistStamped():
      stamp(),
      left_wheel(0),
      right_wheel(0)
    {
    }

    virtual int serialize(unsigned char *outbuffer) const
    {
      int offset = 0;
      *(outbuffer + offset + 0) = (this->stamp.sec >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->stamp.sec >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->stamp.sec >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->stamp.sec >> (8 * 3)) & 0xFF;
      offset += sizeof(this->stamp.sec);
      *(outbuffer + offset + 0) = (this->stamp.nsec >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->stamp.nsec >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->stamp.nsec >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->stamp.nsec >> (8 * 3)) & 0xFF;
      offset += sizeof(this->stamp.nsec);
      union {
        float real;
        uint32_t base;
      } u_left_wheel;
      u_left_wheel.real = this->left_wheel;
      *(outbuffer + offset + 0) = (u_left_wheel.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_left_wheel.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_left_wheel.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_left_wheel.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->left_wheel);
      union {
        float real;
        uint32_t base;
      } u_right_wheel;
      u_right_wheel.real = this->right_wheel;
      *(outbuffer + offset + 0) = (u_right_wheel.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_right_wheel.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_right_wheel.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_right_wheel.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->right_wheel);
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer)
    {
      int offset = 0;
      this->stamp.sec =  ((uint32_t) (*(inbuffer + offset)));
      this->stamp.sec |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      this->stamp.sec |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      this->stamp.sec |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      offset += sizeof(this->stamp.sec);
      this->stamp.nsec =  ((uint32_t) (*(inbuffer + offset)));
      this->stamp.nsec |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      this->stamp.nsec |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      this->stamp.nsec |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      offset += sizeof(this->stamp.nsec);
      union {
        float real;
        uint32_t base;
      } u_left_wheel;
      u_left_wheel.base = 0;
      u_left_wheel.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_left_wheel.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_left_wheel.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_left_wheel.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->left_wheel = u_left_wheel.real;
      offset += sizeof(this->left_wheel);
      union {
        float real;
        uint32_t base;
      } u_right_wheel;
      u_right_wheel.base = 0;
      u_right_wheel.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_right_wheel.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_right_wheel.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_right_wheel.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->right_wheel = u_right_wheel.real;
      offset += sizeof(this->right_wheel);
     return offset;
    }

    const char * getType(){ return "hardware_msgs/TwistStamped"; };
    const char * getMD5(){ return "0c69fe66f8e726754f37e3cdff818b74"; };

  };

}
#endif
